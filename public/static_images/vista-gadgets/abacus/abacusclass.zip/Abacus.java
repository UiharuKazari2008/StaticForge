
/*
 * Copyright (c) 1995 Luis Fernandes
 *
 * Permission to use, copy, hack, and distribute this software and its
 * documentation for NON-COMMERCIAL purposes without fee is hereby
 * granted provided that this copyright notice appears in all copies.
 *
 * COMMERCIAL licenses are available for a tiny cost.
 * 
 */

/* $Id: Abacus.java,v 1.7 1996/05/30 20:22:16 elf Exp $ */

/* $Log: Abacus.java,v $
 * Revision 1.7  1996/05/30 20:22:16  elf
 * Support for parameters to override images for the frame and beads.
 *
 * Support for tourist information (customizable params, etc.) via the
 * appletviewer-menu added.
 *
 * Removed ux,uy (clipping coords) which were not used.
 *
 * Image-update is bouble-buffered (done in the previous version).
 *
 * After reading JAG/KA's _TJPL_, I've decided that this applet needs a
 * major re-write.
 *
 * Revision 1.6  1996/05/22 19:33:33  elf
 * The frame is now a gif representation.
 *
 * Revision 1.5  1996/04/04  18:32:05  elf
 * Also display the value in the java console, since there is a bug in
 * Netscape that does not show it in the frame.
 *
 * Revision 1.4  1996/03/01  21:41:34  elf
 * In update(), instead of calling paint(), just re-draw the columns. The
 * re-draw looks better now.
 *
 * Revision 1.3  1996/01/12  19:18:40  elf
 * In mouseMove, if the column-returned in cx is >=NCOLS (which is
 * possible), trap-it (used to be an ArrayIndexOutOfBoundsException).
 * I think translateXY2RowCol should do this trapping.
 *
 * Revision 1.2  1996/01/10  20:47:29  elf
 * Track the mouse and display descriptive-information in the status
 * area about the anatomy of the abacus.
 *
 * Revision 1.1  1995/09/25  20:15:07  elf
 * Initial revision
 */ 

import java.awt.*;

/** This is a java-applet simulation of a Chinese abacus. 
 *
 *
 * Each column is stored internally in an integer array called
 * 'column' that is initialized to represent the resting positions of
 * the beads: 2 bead on top deck row-pos 0 & 1, pos 2 empty; 5 beads
 * lower deck pos 4-8, pos 3 empty. The initial value is
 * 499d=111110011 where a '1' represents a position that is occupied
 * by a bead and a '0' represents an empty position. As the beads are
 * moved, the 1's are shifted (using << and >>) accordingly to
 * represent their new locations.
 * 
 * The illustration below represents a single column of the abacus.
 * 
<pre> 
   O represents the bead; 
   | represents an empty position (the rod)
   = represents the frame
  
  	=============	Row Position (index 'r' )
  		O			0
  		O			1			Upper Deck
  		|			2
  	=============
  		|			3
  		O			4
  		O			5			Lower Deck
  		O			6
  		O			7
  		O			8
	=============
</pre>
 *
 * @author Luis Fernandes
 */


